#!/usr/bin/env python3
import requests
import sys
import time

BACKEND_URL = "http://backend:8000/recommend"
HEALTH_URL = "http://backend:8000/health"

try:
    h = requests.get(HEALTH_URL, timeout=3)
    if h.status_code != 200:
        print(f"CRITICAL - health status {h.status_code}")
        sys.exit(2)
except Exception as e:
    print(f"CRITICAL - health check failed: {e}")
    sys.exit(2)

try:
    params = {"q": "python basics", "top_n": 1}
    t0 = time.time()
    r = requests.get(BACKEND_URL, params=params, timeout=5)
    elapsed = time.time() - t0
    if r.ok:
        print(f"OK - recommend OK | response_time={elapsed:.3f}s")
        sys.exit(0)
    else:
        print(f"CRITICAL - recommend failed: {r.status_code}")
        sys.exit(2)
except Exception as e:
    print(f"CRITICAL - recommend exception: {e}")
    sys.exit(2)
