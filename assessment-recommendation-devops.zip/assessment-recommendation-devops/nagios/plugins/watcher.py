#!/usr/bin/env python3
import time, subprocess
while True:
    try:
        out = subprocess.run(['/opt/nagios/libexec/check_recommend.py'], capture_output=True, text=True, timeout=10)
        print(time.strftime("%Y-%m-%d %H:%M:%S"), out.stdout.strip())
    except Exception as e:
        print(time.strftime("%Y-%m-%d %H:%M:%S"), "ERROR:", e)
    time.sleep(30)
