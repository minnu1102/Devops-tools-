from fastapi import FastAPI, Query
from pydantic import BaseModel
from model import recommender
from typing import List

app = FastAPI(title="Assessment Recommendation Engine")

class RecOut(BaseModel):
    id: int
    title: str
    description: str
    score: float

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/recommend", response_model=List[RecOut])
def recommend(q: str = Query(..., min_length=1), top_n: int = 5):
    results = recommender.recommend(q, top_n=top_n)
    return results
