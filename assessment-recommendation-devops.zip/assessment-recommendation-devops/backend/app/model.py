import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import os

DATA_PATH = os.path.join(os.path.dirname(__file__), "sample_data.csv")

class Recommender:
    def __init__(self):
        self.df = pd.read_csv(DATA_PATH)
        self.tfidf = TfidfVectorizer(stop_words='english')
        self.tfidf_matrix = self.tfidf.fit_transform(self.df['description'].fillna(''))

    def recommend(self, query, top_n=5):
        q_vec = self.tfidf.transform([query])
        sim = cosine_similarity(q_vec, self.tfidf_matrix)[0]
        self.df['score'] = sim
        out = self.df.sort_values(by='score', ascending=False).head(top_n)
        return out[['id','title','description','score']].to_dict(orient='records')

# instantiate a global recommender for FastAPI to use
recommender = Recommender()
