# Assessment Recommendation Engine with DevOps Automation

## Overview
This repo contains an NLP-based assessment recommender (FastAPI backend + Streamlit frontend) integrated with DevOps automation using Docker, Puppet, Ansible, and Nagios.

## Quick start (Docker Compose)
1. Ensure Docker & docker-compose are installed.
2. From repo root, run:
   docker compose up --build
3. Open in browser:
   - Streamlit UI: http://localhost:8501
   - FastAPI docs: http://localhost:8000/docs
4. View Nagios watcher logs:
   docker logs -f are_nagios

## Puppet (optional)
Run puppet apply to bootstrap host (Ubuntu):
  sudo puppet apply puppet/manifests/site.pp

## Ansible (optional)
Install community.docker collection:
  ansible-galaxy collection install community.docker
Then run:
  ansible-playbook ansible/deploy.yml -c local

## Notes
- Nagios included here is a minimal demo watcher. Replace with full Nagios Core for production UI.
- TF-IDF based recommender is simple and fast; replace with transformer models for semantic matching.
