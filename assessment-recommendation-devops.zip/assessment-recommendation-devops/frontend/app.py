import streamlit as st
    import requests
    from urllib.parse import urlencode

    st.set_page_config(page_title="Assessment Recommender", layout="centered")
    st.title("Assessment Recommendation Engine")

    st.write("Enter your learning goal or topic and get recommended assessments.")

    query = st.text_input("Explain what you want to learn (e.g., 'practice SQL queries')")

    top_n = st.slider("Top N", min_value=1, max_value=10, value=5)

    if st.button("Get Recommendations"):
        if not query.strip():
            st.warning("Please enter a query.")
        else:
            try:
                params = urlencode({"q": query, "top_n": top_n})
                url = f"http://backend:8000/recommend?{params}"
                resp = requests.get(url, timeout=5)
                if resp.ok:
                    recs = resp.json()
                    for r in recs:
                        st.markdown(f"**{r['title']}**  
{r['description']}  
Score: {r['score']:.4f}")
                else:
                    st.error(f"Backend error: {resp.status_code}")
            except Exception as e:
                st.error(f"Error contacting backend: {e}")
